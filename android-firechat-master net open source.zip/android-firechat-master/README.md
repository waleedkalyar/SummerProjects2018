# [ FIRECHAT ]

Simple Android Chat Implementation using <a href="https://www.firebase.com" target="_blank">Firebase</a> .

<a href="https://drive.google.com/open?id=0B2r_spvOc5ZBNEhZeDBDYjAzMjQ" target="_blank">[ APK DOWNLOAD ]</a>


## Release History

* 1.0.0 First version